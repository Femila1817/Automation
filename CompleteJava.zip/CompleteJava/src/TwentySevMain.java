
public class TwentySevMain {

	public static void main(String[] args) {

		TwentySevEncapsulationC s1 = new TwentySevEncapsulationC();
		
		s1.setRollno(2);
		s1.setName("Jerry");
		
		System.out.println(s1.getRollno());
		System.out.println(s1.getName());
		

	}

}
