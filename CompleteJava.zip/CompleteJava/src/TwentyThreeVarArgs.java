
public class TwentyThreeVarArgs {

	public static void main(String[] args) {
		
		TwentythreeCalc a = new TwentythreeCalc();
		//TwentythreeCalc b = new TwentythreeCalc();
		
			//System.out.println(a.add(5, 15,4)); //if we have given only 2 and we need to add more number.. er have to configure acc in class
		//System.out.println(a.sum(5, 15,4));

	}

}
