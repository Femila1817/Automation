
public class ThirteenClassCalc {
int num1; //variables
int num2;
int result;
	
	public void perform() //method
	{
		result = num1 + num2;
		System.out.println(result);
	}

}
