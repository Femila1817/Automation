
public class ThirtyOneFinalKeyMain {

	public static void main(String[] args) {
		
		//ThirtyOneFinalKeyC A = new ThirtyOneFinalKeyC();
		//System.out.println(A.i);

		//B A1 = new B();
		//A1.show();
	}

}
