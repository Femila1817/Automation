
public class TwentyArrayClass { //consider as student class
	
	int rollno;
	String name;
}
