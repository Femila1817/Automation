
public class TwentyTwoEnhancedForLoop {

	public static void main(String[] args) {
		
		int a[] = {1,2,3};
		
//		for(int i = 0; i<= 2 ;i++){
//			System.out.println(a[i]);
//		}
		for(int temp : a){
			System.out.print(temp);
		}
	}

}
