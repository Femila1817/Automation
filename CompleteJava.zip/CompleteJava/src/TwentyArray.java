
public class TwentyArray {

	public static void main(String[] args) {
		TwentyArrayClass s1 = new TwentyArrayClass();
		TwentyArrayClass s2 = new TwentyArrayClass();
		TwentyArrayClass s3 = new TwentyArrayClass();
		TwentyArrayClass s4 = new TwentyArrayClass();
		
		TwentyArrayClass s[] = {s1,s2,s3,s4};
		
		

	}

}
