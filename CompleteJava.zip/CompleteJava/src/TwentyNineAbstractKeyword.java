//can be used in abstract class and method
public class TwentyNineAbstractKeyword {

	public static void main(String[] args) {
		
		//TwentyNineC obj = new TwentyNineC(); cannot create object for abstract class. so how to do?
		
		// we need to create  a subclass which extends superclass[which is abstract]

	}

}
