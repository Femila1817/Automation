package com.femila;

import com.femila.test.THNStudent; //import student

public class THNEngineer extends THNStudent{

	public void show(){
		mark = 77;
		
		//age = 45; not working in root package of student too
	}

}
