package com.femila;

public class TwoVariable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		/// we can create same class files in different package
		
		
		
		
		//package example
	}

}
