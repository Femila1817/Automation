
public class ThreeOperator {

	/*
	 * Arithmetic
	 * Bitwise
	 * Relational
	 * logical
*/

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
	/*	int m = 5, n = 2;
		int r1 = m + n;
		int r2 = m - n;
		int r3 =  m * n;
		double  r4 = (double) m / n;
		int r5 = m % n;
		System.out.println("r1 :" + r1);
		System.out.println("r2 :" + r2);
		System.out.println("r3 :" + r3);
		System.out.println("r4 :" + r4);
		System.out.println("r5 :" + r5);*/
		
		int m = 4;
		int n = 5 ;
		// n += m ;//n = n + m;
		// n++ // n +=1 ; n=  n +  1 //post increment both called shorthand operators
		//++n; //pre increment
		
		m = ++n  ;
		
		System.out.println(m);
		
	}

}
