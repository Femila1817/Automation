
public class ThirtyAbstractMain {

	public static void main(String[] args) {
		
		ThirtyAbstractCExam p1 = new ThirtyAbstractCExam();
		p1.show(5.5);//if v need to pass double value  // so "Number" class support both int and float
	}

}
