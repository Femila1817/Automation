
public class SixteenConstructorOverload {

	public static void main(String[] args) {
		
		SixteenClassCasio obj = new SixteenClassCasio(4,5,"add"); //-- the paramter passed,determine which constructor tp be called
		
//Here it calls the 4th constructor
	}

}
