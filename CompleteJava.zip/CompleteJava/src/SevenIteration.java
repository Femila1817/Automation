
public class SevenIteration {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
/*
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

this is code redundancy*/
		/*int i = 1; // initialization statement
		while(i<=5) //condition
		{
			System.out.println("Hello");  while loop
			i++; //increment or decrement statement
		}
		*/
		/*int i = 5;
		do{
		System.out.println("World");
		i++;
		}while(i <= 10);*/
		
		for(int i=0;i<=5; i++){
			System.out.println("Test");
		}
	}

}
