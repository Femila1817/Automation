
public class FourteenConstructor {

	public static void main(String[] args) {
		
		FourteenClassCalc test = new FourteenClassCalc(4,6.5);
		
		System.out.println(test.num1);
		System.out.println(test.num2);
		System.out.println("in constructor");
	}

}
