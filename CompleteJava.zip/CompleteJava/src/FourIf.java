
public class FourIf {

	public static void main(String[] args) {
		
		int n = 0;
		
		int m =  n % 2;
						
		if(n == 0){
			System.out.println("Nothing");
		}else if(m == 0){
			System.out.println("even number");
		}else {
			System.out.println("odd number");
	}
	}
}


