
public class FifteenMethodOverload {

	public static void main(String[] args) {

		FifteenClassCasio obj = new FifteenClassCasio();
		obj.add(5, 7);
		obj.add(3, 5,6);
		obj.add(5.5, 7.3);
	}

}

