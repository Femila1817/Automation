
public class ThirteenClassObject {

	public static void main(String[] args) {
			
		ThirteenClassCalc obj = new ThirteenClassCalc(); //ref  obj knows something and does somethin. create obj
		
		obj.num1 = 3;
		obj.num2 = 2;
		obj.perform();

	}

}
